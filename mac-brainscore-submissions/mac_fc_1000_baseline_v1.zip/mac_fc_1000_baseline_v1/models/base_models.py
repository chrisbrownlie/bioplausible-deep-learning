import functools

import torchvision.models
from model_tools.activations.pytorch import PytorchWrapper
from model_tools.activations.pytorch import load_preprocess_images
import torch
import torch.nn as nn
import torch.nn.functional as F

# This is an example implementation for submitting alexnet as a pytorch model
# If you use pytorch, don't forget to add it to the setup.py

# Attention: It is important, that the wrapper identifier is unique per model!
# The results will otherwise be the same due to brain-scores internal result caching mechanism.
# Please load your pytorch model for usage in CPU. There won't be GPUs available for scoring your model.
# If the model requires a GPU, contact the brain-score team directly.
from model_tools.check_submission import check_models

# Simple MLP for CIFAR10 image classification
class simpleModel(nn.Module):
    def __init__(self):
        super(simpleModel, self).__init__()

        self.fc1 = nn.Linear(3072, 1536)
        self.fc2 = nn.Linear(1536, 256)
        self.fc3 = nn.Linear(256, 1000)

    def forward(self, x):
        x = x.view(x.size(0), -1) # flatten tensor for the final, linear layers
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x) # softmax is used on this layer when calculating loss
    
        return x

def get_model_list():
    return ['m-fc-baseline']


def get_model(name):
    assert name == 'm-fc-baseline'
    model = simpleModel()
    #model.load_state_dict(torch.load("models/FC_Baseline_v2.pth"))

    #test output of model
    #r_d = torch.randn(4,3,32,32)
    #print("\n\ntest output of model is:\n")
    #print(model(r_d))

    preprocessing = functools.partial(load_preprocess_images, image_size=32)
    wrapper = PytorchWrapper(identifier='m-fc-baseline', model=model, preprocessing=preprocessing)
    wrapper.image_size = 32
    print(wrapper)
    return wrapper


def get_layers(name):
    assert name == 'm-fc-baseline'
    return ['fc1', 'fc2']


def get_bibtex(model_identifier):
    return None


if __name__ == '__main__':
    check_models.check_base_models(__name__)
